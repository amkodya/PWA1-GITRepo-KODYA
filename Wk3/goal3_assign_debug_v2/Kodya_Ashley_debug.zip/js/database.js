var db = [
	"JavaScript Version History|http://wddbs.com/javascript/sfw/online/#p=videos&s=3&file=01.html",   //removed http:// x 1
	"JavaScript in the Browser|http://wddbs.com/javascript/sfw/online/#p=videos&s=3&file=01.html",
	"Script Tag|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"JavaScript Syntax|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Data Type Literals|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Strings & HTML Strings|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Numbers|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Arrays|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Objects|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Functions|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Scope|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Loops|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Conditionals|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Typeof|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Timers|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Native Objects|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=02.html",
	"Debugging Tools|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=03.html",
	"Firebug|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=03.html",
	"Error Types|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=03.html",
	"Closures|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=04.html",
	"Context|http://wddbs.com/javascript/sfw/online/#p=videos&s=1&file=04.html"
];